
// Clases de la biblioteca

import * as THREE from '../libs/three.module.js'
import { GUI } from '../libs/dat.gui.module.js'
import { TrackballControls } from '../libs/TrackballControls.js'
import  Stats from '../libs/stats.module.js'
import * as TWEEN from '../libs/tween.module.js'
import { MTLLoader } from '../libs/MTLLoader.js';
import { OBJLoader} from '../libs/OBJLoader.js'
// Clases de mi proyecto
import { Tablero,lila } from './Tablero.js'
import { Casilla } from './Casilla.js'
import { Pieza } from './Pieza.js'
import { Reina } from './Reina.js'
/// La clase fachada del modelo
/**
 * Usaremos una clase derivada de la clase Scene de Three.js para llevar el control de la escena y de todo lo que ocurre en ella.
 */

class MyScene extends THREE.Scene {
  constructor (myCanvas) {
    super();
    
    // Lo primero, crear el visualizador, pasándole el lienzo sobre el que realizar los renderizados.
    this.renderer = this.createRenderer(myCanvas);
    
    // Se añade a la gui los controles para manipular los elementos de esta clase
    this.gui = this.createGUI ();
    
    this.initStats();
    
    // Construimos los distinos elementos que tendremos en la escena
    this.createCamera();
    
    // Todo elemento que se desee sea tenido en cuenta en el renderizado de la escena debe pertenecer a esta. Bien como hijo de la escena (this en esta clase) o como hijo de un elemento que ya esté en la escena.
    // Tras crear cada elemento se añadirá a la escena con   this.add(variable)
    this.createLights ();
    
    // Un suelo 
    this.createGround ();
    
    // Y unos ejes. Imprescindibles para orientarnos sobre dónde están las cosas
    // Todas las unidades están en metros
    this.axis = new THREE.AxesHelper (2);
    this.add (this.axis);
    
    //Fondo
    this.cargarEntorno();
    
    // Por último creamos el modelo.
    // El modelo puede incluir su parte de la interfaz gráfica de usuario. Le pasamos la referencia a 
    // la gui y el texto bajo el que se agruparán los controles de la interfaz que añada el modelo.
    this.model = new Tablero(this.gui, "Controles de la Caja");
    this.add (this.model);

    this.raycaster = new THREE.Raycaster();
    this.mouse = new THREE.Vector2();
    this.piezaSeleccionada = null;
    this.casillas_validas = null;
    this.casilla_seleccionada = null;
    this.estado = 0; //esperando pieza
    this.turno = "blanco";

    this.camara = new THREE.Object3D();
    this.camara.add(this.getCamera());
    this.add(this.camara);
    this.cambiarCamara(this.turno);
    

    window.addEventListener('click', (event) => this.onClick(event));
  }

  onClick(event) {
     this.mouse.x = (event.clientX / window.innerWidth) * 2 - 1;
     this.mouse.y = 1 - 2 * (event.clientY / window.innerHeight);

     this.raycaster.setFromCamera(this.mouse,this.camera);

     if(this.estado == 0) {
      if(this.turno == "lila") {
        var pickedObjects = this.raycaster.intersectObjects(this.model.piezas_seleccionables_lilas,true);
      }
      else if(this.turno == "blanco") {
        var pickedObjects = this.raycaster.intersectObjects(this.model.piezas_seleccionables_blancas,true);
      }
      
      console.log(pickedObjects);
      if(pickedObjects.length>0) {
        let nodo = pickedObjects[0].object;
        while(nodo) {
         if(nodo.userData && nodo.userData.refPieza) {
           this.piezaSeleccionada = nodo.userData.refPieza;
           break;
         }
         nodo = nodo.parent;
        }
 
        if(this.piezaSeleccionada && typeof this.piezaSeleccionada.onClick === 'function') {
         this.casillas_validas = this.piezaSeleccionada.onClick(this.model.casillas);
         if(this.casillas_validas.length>0) {
          this.estado = 1; //esperando casilla
         }
         else {
          this.estado = 0; //elegir otra pieza
         }
         
        }
        else {
         console.log("Objeto seleccionado no tiene onClick");
        }
      } 
     }
    
     else if(this.estado == 1) {
      var pickedCasillas = this.raycaster.intersectObjects(this.casillas_validas,true);
      if (pickedCasillas.length > 0 && this.piezaSeleccionada) {
        this.casilla_seleccionada = pickedCasillas[0].object.userData;

          //Si la reina va a capturar una pieza, cambiamos la cámara y hacemos la lucha
          if(this.piezaSeleccionada instanceof Reina && this.casilla_seleccionada.pieza != null) {
            this.cambiarCamaraLucha();
            this.piezaSeleccionada.lucha(this.piezaSeleccionada,this.casilla_seleccionada,this.model,this);
          }
          else {
            
            // Movemos la pieza a la casilla seleccionada
            this.piezaSeleccionada.mover(this.casilla_seleccionada,this.model,this);

          }

          //Limpiamos las casillas válidas
          this.piezaSeleccionada.seleccionada = !this.piezaSeleccionada.seleccionada;
          this.casillas_validas.forEach(casilla_valida => {
            casilla_valida.setColor(casilla_valida.colorInicial);
          }) 
          
          this.estado = 0;
    
          // Limpiamos los atributos correspondientes
          this.piezaSeleccionada = null;
          this.casilla_seleccionada = null;
          this.casillas_validas = null;
          
      }
     }
    
  }
     
  cargarEntorno() {
    var path = "../imgs/Cielo/" ;
    var format = '.png';
    var urls = [
      path + 'px' + format , path + 'nx' + format,
      path + 'py' + format , path + 'ny' + format,
      path + 'pz' + format , path + 'nz' + format
    ] ;
    var textureCube = new THREE.CubeTextureLoader().load(urls) ;
    this.background = textureCube ;
  }
  initStats() {
  
    var stats = new Stats();
    
    stats.setMode(0); // 0: fps, 1: ms
    
    // Align top-left
    stats.domElement.style.position = 'absolute';
    stats.domElement.style.left = '0px';
    stats.domElement.style.top = '0px';
    
    $("#Stats-output").append( stats.domElement );
    
    this.stats = stats;
  }
  
  createCamera () {
    // Para crear una cámara le indicamos
    //   El ángulo del campo de visión en grados sexagesimales
    //   La razón de aspecto ancho/alto
    //   Los planos de recorte cercano y lejano
    this.camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 50);
      // Recuerda: Todas las unidades están en metros
      // También se indica dónde se coloca
      this.camera.position.set (5, 10, 5);
      // Y hacia dónde mira
      var look = new THREE.Vector3 (0,0,0);
      this.camera.lookAt(look);
    
    // Para el control de cámara usamos una clase que ya tiene implementado los movimientos de órbita
    this.cameraControl = new TrackballControls (this.camera, this.renderer.domElement);
    // Se configuran las velocidades de los movimientos
    this.cameraControl.rotateSpeed = 5;
    this.cameraControl.zoomSpeed = -2;
    this.cameraControl.panSpeed = 0.5;
    // Debe orbitar con respecto al punto de mira de la cámara
    this.cameraControl.target = look;
  }

  cambiarCamara(turno) {
  
    let angulo = 0;

    if(turno == "lila") {
      angulo = -Math.PI/4;
    }
    else if(turno == "blanco") {
      angulo = 3*Math.PI/4;
    }

    // Guardamos el valor actual de rotación
    const actual = { y: this.camara.rotation.y };

    // Rotamos la cámara
    new TWEEN.Tween(actual)
      .to({ y: angulo }, 1000)
      .easing(TWEEN.Easing.Quadratic.InOut)
      .onUpdate(() => {
        this.camara.rotation.y = actual.y;
      })
      .start();
  }

  cambiarCamaraLucha() {

    // Guardamos el valor actual de rotación
    const actual = { y: this.camara.rotation.y };

    // Rotamos la cámara
    new TWEEN.Tween(actual)
      .to({ y: this.camara.rotation.y-Math.PI/2}, 1000)
      .easing(TWEEN.Easing.Quadratic.InOut)
      .onUpdate(() => {
        this.camara.rotation.y = actual.y;
      })
      .start();
  }
  
  createGround () {
    // El suelo es un Mesh, necesita una geometría y un material.
    var materialLoader = new MTLLoader();
    var objectLoader = new OBJLoader();
    materialLoader.load('../models/Avion/11805_airplane_v2_L2.mtl',
        (materials) => {
            objectLoader.setMaterials(materials);
            objectLoader.load('../models/Avion/11805_airplane_v2_L2.obj',
                (object) => {
                    object.scale.set(0.05,0.05,0.05);
                    object.rotation.x = -Math.PI/2;
                    object.position.y = -8;
                    object.position.x = -11;
                    object.position.z -= 0.7;
                    this.add(object);
                }, null, null);
        }
    );
    
    // La geometría es una caja con muy poca altura
    var geometryGround = new THREE.BoxGeometry (10,0.2,10);
    
    // El material se hará con una textura de madera
    var texture = new THREE.TextureLoader().load('../imgs/wood.jpg');
    var materialGround = new THREE.MeshStandardMaterial ({map: texture});
    
    // Ya se puede construir el Mesh
    var ground = new THREE.Mesh (geometryGround, materialGround);
    
    // Todas las figuras se crean centradas en el origen.
    // El suelo lo bajamos la mitad de su altura para que el origen del mundo se quede en su lado superior
    ground.position.y = -0.125;
    
    // Que no se nos olvide añadirlo a la escena, que en este caso es  this
    this.add (ground);
   
  }
  
  createGUI () {
    // Se crea la interfaz gráfica de usuario
    var gui = new GUI();
    
    // La escena le va a añadir sus propios controles. 
    // Se definen mediante un objeto de control
    // En este caso la intensidad de la luz y si se muestran o no los ejes
    this.guiControls = {
      // En el contexto de una función   this   alude a la función
      lightPower : 500.0,  // La potencia de esta fuente de luz se mide en lúmenes
      ambientIntensity : 0.5,   
      axisOnOff : true
    }

    // Se crea una sección para los controles de esta clase
    var folder = gui.addFolder ('Luz y Ejes');
    
    // Se le añade un control para la potencia de la luz puntual
    folder.add (this.guiControls, 'lightPower', 0, 1000, 20)
      .name('Luz puntual : ')
      .onChange ( (value) => this.setLightPower(value) );
    
    // Otro para la intensidad de la luz ambiental
    folder.add (this.guiControls, 'ambientIntensity', 0, 1, 0.05)
      .name('Luz ambiental: ')
      .onChange ( (value) => this.setAmbientIntensity(value) );
      
    // Y otro para mostrar u ocultar los ejes
    folder.add (this.guiControls, 'axisOnOff')
      .name ('Mostrar ejes : ')
      .onChange ( (value) => this.setAxisVisible (value) );
    
    return gui;
  }
  
  createLights () {
    // Se crea una luz ambiental, evita que se vean complentamente negras las zonas donde no incide de manera directa una fuente de luz
    // La luz ambiental solo tiene un color y una intensidad
    // Se declara como   var   y va a ser una variable local a este método
    //    se hace así puesto que no va a ser accedida desde otros métodos
    this.ambientLight = new THREE.AmbientLight("white", this.guiControls.ambientIntensity);
    // La añadimos a la escena
    this.add (this.ambientLight);
    
    // Se crea una luz focal que va a ser la luz principal de la escena
    // La luz focal, además tiene una posición, y un punto de mira
    // Si no se le da punto de mira, apuntará al (0,0,0) en coordenadas del mundo
    // En este caso se declara como   this.atributo   para que sea un atributo accesible desde otros métodos.
    this.pointLight = new THREE.PointLight( 0xffffff );
    this.pointLight.power = this.guiControls.lightPower;
    this.pointLight.position.set( 0, 3, 0 );
    this.add (this.pointLight);
  }
  
  setLightPower (valor) {
    this.pointLight.power = valor;
  }

  setAmbientIntensity (valor) {
    this.ambientLight.intensity = valor;
  }  
  
  setAxisVisible (valor) {
    this.axis.visible = valor;
  }
  
  createRenderer (myCanvas) {
    // Se recibe el lienzo sobre el que se van a hacer los renderizados. Un div definido en el html.
    
    // Se instancia un Renderer   WebGL
    var renderer = new THREE.WebGLRenderer();
    
    // Se establece un color de fondo en las imágenes que genera el render
    renderer.setClearColor(new THREE.Color(0xEEEEEE), 1.0);
    
    // Se establece el tamaño, se aprovecha la totalidad de la ventana del navegador
    renderer.setSize(window.innerWidth, window.innerHeight);
    
    // La visualización se muestra en el lienzo recibido
    $(myCanvas).append(renderer.domElement);
    
    return renderer;  
  }
  
  getCamera () {
    // En principio se devuelve la única cámara que tenemos
    // Si hubiera varias cámaras, este método decidiría qué cámara devuelve cada vez que es consultado
    return this.camera;
  }
  
  setCameraAspect (ratio) {
    // Cada vez que el usuario modifica el tamaño de la ventana desde el gestor de ventanas de
    // su sistema operativo hay que actualizar el ratio de aspecto de la cámara
    this.camera.aspect = ratio;
    // Y si se cambia ese dato hay que actualizar la matriz de proyección de la cámara
    this.camera.updateProjectionMatrix();
  }
  
  onWindowResize () {
    // Este método es llamado cada vez que el usuario modifica el tamapo de la ventana de la aplicación
    // Hay que actualizar el ratio de aspecto de la cámara
    this.setCameraAspect (window.innerWidth / window.innerHeight);
    
    // Y también el tamaño del renderizador
    this.renderer.setSize (window.innerWidth, window.innerHeight);
  }

  update () {
    
    if (this.stats) this.stats.update();
    
    // Se actualizan los elementos de la escena para cada frame
    
    // Se actualiza la posición de la cámara según su controlador
    this.cameraControl.update();
    
    // Se actualiza el resto del modelo
    this.model.update();
    
    // Le decimos al renderizador "visualiza la escena que te indico usando la cámara que te estoy pasando"
    this.renderer.render (this, this.getCamera());

    // Este método debe ser llamado cada vez que queramos visualizar la escena de nuevo.
    // Literalmente le decimos al navegador: "La próxima vez que haya que refrescar la pantalla, llama al método que te indico".
    // Si no existiera esta línea,  update()  se ejecutaría solo la primera vez.
    requestAnimationFrame(() => this.update())

    TWEEN.update();
  }
}

/// La función   main
$(function () {
  
  // Se instancia la escena pasándole el  div  que se ha creado en el html para visualizar
  var scene = new MyScene("#WebGL-output");

  // Se añaden los listener de la aplicación. En este caso, el que va a comprobar cuándo se modifica el tamaño de la ventana de la aplicación.
  window.addEventListener ("resize", () => scene.onWindowResize());
  
  // Que no se nos olvide, la primera visualización.
  scene.update();
});
